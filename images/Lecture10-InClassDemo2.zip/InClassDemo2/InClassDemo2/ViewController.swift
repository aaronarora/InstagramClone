//
//  ViewController.swift
//  InClassDemo2
//
//  Created by Todd Sproull on 6/25/20.
//  Copyright © 2020 Todd Sproull. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate  {
    
    
    @IBOutlet weak var tableView: UITableView!
    

    struct Info: Codable {
        var name: String
        var description: String
        var image_url: String
    }
    
    var theData: [Info] = []
    var theImageCache: [UIImage] = []
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        setupTableView()
        DispatchQueue.global(qos: .userInitiated).async {
            self.fetchDataForTableView()
            self.cacheImages()
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }

        }
        
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return theData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        cell.textLabel!.text = theData[indexPath.row].name
        cell.imageView?.image = theImageCache[indexPath.row]
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        print("in here")

        
        let detailedVC = DetailedViewController()
        detailedVC.image = theImageCache[indexPath.row]
        detailedVC.imageName = theData[indexPath.row].name
        
        navigationController?.pushViewController(detailedVC, animated: true)
        
        
    }
    
    func setupTableView() {
        tableView.dataSource = self
        tableView.delegate = self
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        
    }
    
    
    
    func fetchDataForTableView() {
        let url = URL(string: "https://research.engineering.wustl.edu/~todd/studio.json")
        let data = try! Data(contentsOf: url!)
        theData = try! JSONDecoder().decode([Info].self, from:data)
        print("the data is \(theData)")
        
    }
    func cacheImages() {
          //URL
          //Data
          //UIImage
        for item in theData {
            let url = URL(string: item.image_url)
            let data = try? Data(contentsOf: url!)
            let image = UIImage(data: data!)
            theImageCache.append(image!)
        }
    }

}

